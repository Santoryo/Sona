Hey, thank you for using Sona!
If you would like to support me you can do it here:
https://ko-fi.com/Santoryo

To edit the format of your status go to config.ini and edit it with Notepad/Notepad++/VSCode or any other text editor

Works only on Windows.



Sona isn't endorsed by Riot Games and doesn't reflect the views or opinions of Riot Games or anyone officially involved in producing or managing Riot Games properties. Riot Games, and all associated properties are trademarks or registered trademarks of Riot Games, Inc.